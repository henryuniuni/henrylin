#define _GNU_SOURCE
#include <stdio.h>
#include <pthread.h>
#include <stdatomic.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

#define NONE "\033[m"
#define RED "\033[0;32;31m"
#define YELLOW "\033[1;33m"

struct timespec ts = {0, 100};
struct timespec nanoSleepTs = {0, 0};

atomic_int current = 0;
long long* inCS;
long masterID = 0;   //masterID is the biggest one
int isMutex = 0;

void per_5seconds(int signum) {
    static int run = 0;
    printf(YELLOW"run [%3d]  "NONE, run++);
    for (int i=0; i<= masterID; i++) {
        printf("%lld ", inCS[i]);
    }
    printf("\n");
    alarm(5);
}

void slave(void *_name) {
    long name = (long)_name;
    int expected;

    int s, j;
    cpu_set_t cpuset;
    pthread_t thread;

    thread = pthread_self();
    CPU_ZERO(&cpuset);
    CPU_SET((int)name, &cpuset);
    //綁定處理器
    pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);


    printf("slave: start p%ld\n", name);
    while (1) {
        while (!atomic_compare_exchange_weak(&current, &expected, 1)) {
            //printf("P1 waiting for P%d\n", expected);
            expected = 0;
        }
        //執行到這一步驟，表示 current == expected == 0，即拿到了lock
    
        //critical section
        isMutex++;
        //判斷我們的程式有沒有寫錯
        if (isMutex != 1) fprintf(stderr, "mutual execution");
        inCS[name]++;
        isMutex--;
        //離開CS
        current = masterID; //這一行會讓下一個進入CS的為master thread
    }
}

void master(void *_name) {
    long name = (long)_name;
    int expected;

    int s, j;
    cpu_set_t cpuset;
    pthread_t thread;

    thread = pthread_self();
    CPU_ZERO(&cpuset);
    CPU_SET((int)name, &cpuset);
    pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);



    printf("master: start p%ld\n", name);
    while (1) {
        
        while (!atomic_compare_exchange_weak(&current, &expected, masterID)) {
            //printf("P1 waiting for P%d\n", expected);
            expected = masterID;
        }
        //執行到這一步驟，表示 current == expected == masterID，即拿到了lock
        //isMutex是用來計算到底有多少人在CS內
        isMutex++;
        //判斷我們的程式有沒有寫錯
        if (isMutex != 1) fprintf(stderr, "mutual execution");    
        inCS[name]++;
    
        //離開CS之前，將isMutex減一
        isMutex--;
        //解開鎖
        current = 0;
    }
}


int main(void) {
    int numCPU = sysconf( _SC_NPROCESSORS_ONLN );
    printf("num of hardware thread = %d\n", numCPU);
    cpu_set_t cpuset;
    masterID = numCPU-1;
	pthread_t* tid = (pthread_t*)malloc(sizeof(pthread_t) * numCPU);
    inCS = malloc(numCPU * sizeof(long long));
    alarm(5);
    signal(SIGALRM, per_5seconds);
    //create slave
    for (long i=0; i< numCPU-1; i++) {
        pthread_create(&tid[i],NULL,(void *) slave, (void*)i);
        /*
        CPU_ZERO(&cpuset);
        CPU_SET(i, &cpuset);
        int s;
        s = pthread_setaffinity_np(tid[i], sizeof(cpu_set_t), &cpuset);
        if (s != 0)
            perror("pthread_setaffinity_np");
        */
    }
    //create master
    pthread_create(&tid[numCPU],NULL,(void *) master, (void*)masterID);
    /*
    CPU_ZERO(&cpuset);
    CPU_SET(masterID, &cpuset);
    int s;
    s = pthread_setaffinity_np(tid[masterID], sizeof(cpu_set_t), &cpuset);
    if (s != 0)
        perror("pthread_setaffinity_np");
    */

    for (int i=0; i< numCPU; i++)
	    pthread_join(tid[i],NULL);
	return (0);
}
