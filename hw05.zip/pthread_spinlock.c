#define _GNU_SOURCE
#include <stdio.h>
#include <pthread.h>
#include <stdatomic.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

#define NONE "\033[m"
#define RED "\033[0;32;31m"
#define YELLOW "\033[1;33m"

struct timespec ts = {0, 100};
struct timespec nanoSleepTs = {0, 0};

atomic_int current = 0;
long long* inCS;
long masterID = 0;   //masterID is the biggest one
int isMutex = 0;
pthread_spinlock_t plock;
atomic_int masterGetLock = 0;

void per_5seconds(int signum) {
    static int run = 0;
    printf(YELLOW"run [%3d]  "NONE, run++);
    for (int i=0; i<= masterID; i++) {
        printf("%lld ", inCS[i]);
    }
    printf("\n");
    alarm(5);
}

void slave(void *_name) {
    long name = (long)_name;
    int expected;

    int s, j;
    cpu_set_t cpuset;
    pthread_t thread;

    thread = pthread_self();
    CPU_ZERO(&cpuset);
    CPU_SET((int)name, &cpuset);
    pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);

    printf("slave: start p%ld\n", name);
    while (1) {
        pthread_spin_lock(&plock);    
        //critical section
        isMutex++;
        if (isMutex != 1) fprintf(stderr, "mutual execution");
        inCS[name]++;
        isMutex--;
        //離開CS
        pthread_spin_unlock(&plock);   
    }
}

void master(void *_name) {
    long name = (long)_name;

    int s, j;
    cpu_set_t cpuset;
    pthread_t thread;

    thread = pthread_self();
    CPU_ZERO(&cpuset);
    CPU_SET((int)name, &cpuset);
    //將這個thread鎖在特定處理器上面
    pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);

    int expected;
    printf("master: start p%ld\n", name);
    while (1) {
        pthread_spin_lock(&plock);    
        //critical section
        isMutex++;
        //這個地方是判斷我們的程式有沒有寫錯
        if (isMutex != 1) fprintf(stderr, "mutual execution");
        inCS[name]++;
        isMutex--;
        //離開CS
        pthread_spin_unlock(&plock);
    }
}


int main(void) {
    int numCPU = sysconf( _SC_NPROCESSORS_ONLN );
    printf("num of hardware thread = %d\n", numCPU);
    masterID = numCPU-1;
	pthread_t* tid = (pthread_t*)malloc(sizeof(pthread_t) * numCPU);
    inCS = malloc(numCPU * sizeof(long long));
    alarm(5);
    signal(SIGALRM, per_5seconds);
    pthread_spin_init(&plock, PTHREAD_PROCESS_PRIVATE);    
    //slave的名字是0..n-2，假設共有n個硬體執行緒
    for (long i=0; i< numCPU-1; i++) {
        pthread_create(&tid[i],NULL,(void *) slave, (void*)i);
    }
    //master的名字是n-1
    pthread_create(&tid[numCPU],NULL,(void *) master, (void*)masterID);

    for (int i=0; i< numCPU; i++)
	    pthread_join(tid[i],NULL);
	return (0);
}
